BUILD THE APK
1. Install Android Studio (free) and open this folder (the one containing settings.gradle).
2. Let it sync (it downloads Gradle and the SDK automatically).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy it to your phone and tap it to install (allow installs from unknown sources).

To change the app, edit app/src/main/assets/index.html and rebuild.
