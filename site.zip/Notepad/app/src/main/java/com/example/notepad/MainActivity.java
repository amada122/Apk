package com.example.notepad;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        String js = "(function(){var e=document.getElementById('editView'),s=document.getElementById('setView');"
            + "if(e.classList.contains('on')){document.getElementById('backBtn').click();return 1}"
            + "if(s.classList.contains('on')){document.getElementById('setBack').click();return 1}return 0})()";
        web.evaluateJavascript(js, v -> { if ("0".equals(v)) finish(); });
    }
}
